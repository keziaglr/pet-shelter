import view.LoginPage;

public class Main {

	public Main() {
		// TODO Auto-generated constructor stub
		new LoginPage();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
